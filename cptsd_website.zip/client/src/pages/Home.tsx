import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, BookOpen, Lightbulb, Smile } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { APP_TITLE } from "@/const";

export default function Home() {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-pink-500" />
            <h1 className="text-2xl font-bold text-gray-800">{APP_TITLE}</h1>
          </div>
          <div className="hidden md:flex gap-6">
            <Link href="#what-is-cptsd" className="text-gray-700 hover:text-pink-600 font-medium">What is CPTSD?</Link>
            <Link href="#terminology" className="text-gray-700 hover:text-pink-600 font-medium">Terminology</Link>
            <Link href="#symptoms" className="text-gray-700 hover:text-pink-600 font-medium">Symptoms</Link>
            <Link href="#healing" className="text-gray-700 hover:text-pink-600 font-medium">Healing</Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-16 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl font-bold text-gray-800 mb-4">Welcome to Learning About CPTSD</h2>
          <p className="text-xl text-gray-600 mb-8">A guide to understanding Complex Post-Traumatic Stress Disorder in simple, easy-to-understand words.</p>
          <p className="text-lg text-gray-500 mb-12">Whether you're learning for yourself or someone you care about, this website has everything you need to know.</p>
        </div>
      </section>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 pb-16">
        {/* What is CPTSD Section */}
        <section id="what-is-cptsd" className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <Lightbulb className="w-8 h-8 text-yellow-500" />
            <h3 className="text-3xl font-bold text-gray-800">What is CPTSD?</h3>
          </div>
          <Card className="bg-white border-2 border-blue-200">
            <CardHeader>
              <CardTitle className="text-2xl">The Big Hurt</CardTitle>
              <CardDescription className="text-base">Understanding what CPTSD means</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-gray-700">
              <p className="text-lg leading-relaxed">
                Imagine you have a little cut on your knee. That's a <strong>simple hurt</strong>. You put a bandage on it, and it heals.
              </p>
              <p className="text-lg leading-relaxed">
                Now, imagine you have a hurt that keeps happening, like a tiny pebble in your shoe every single day, for a long, long time. This is a <strong>complex hurt</strong>. It's not just one bad day; it's many bad days that make your heart and brain feel tired and scared all the time.
              </p>
              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mt-6">
                <p className="font-bold text-lg text-blue-900 mb-2">CPTSD stands for:</p>
                <ul className="space-y-2 text-blue-800">
                  <li><strong>Complex</strong> - a big, complicated hurt from things that happened over and over</li>
                  <li><strong>Post-Traumatic</strong> - it happens <em>after</em> something scary or hurtful</li>
                  <li><strong>Stress Disorder</strong> - it makes your body and mind feel stressed and out of control</li>
                </ul>
              </div>
              <p className="text-lg leading-relaxed mt-6">
                It usually happens when a person, especially a child, is hurt or scared by people they should be safe with, and they can't escape the situation.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Terminology Section */}
        <section id="terminology" className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <BookOpen className="w-8 h-8 text-purple-500" />
            <h3 className="text-3xl font-bold text-gray-800">Important Words to Know</h3>
          </div>
          <Card className="bg-white border-2 border-purple-200">
            <CardHeader>
              <CardTitle className="text-2xl">Simple Terminology</CardTitle>
              <CardDescription className="text-base">Big words explained in easy ways</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b-2 border-purple-300">
                      <th className="pb-3 font-bold text-gray-800">Big Word</th>
                      <th className="pb-3 font-bold text-gray-800">Simple Meaning</th>
                      <th className="pb-3 font-bold text-gray-800">What It Feels Like</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { word: "Trauma", meaning: "A very scary or hurtful thing that happened", feels: "Like a big, loud storm inside you" },
                      { word: "Chronic", meaning: "Happening over and over for a long time", feels: "Like the storm never stops raining" },
                      { word: "Flashback", meaning: "When your brain tricks you into feeling like the scary thing is happening right now", feels: "Like watching a scary movie, but you're actually in it!" },
                      { word: "Hypervigilance", meaning: "Always being on the lookout for danger, even when you are safe", feels: "Like being a little guard dog that can never rest" },
                      { word: "Emotional Dysregulation", meaning: "Having big feelings that are hard to control", feels: "Like a car with a broken gas pedal and no brakes" },
                      { word: "Dissociation", meaning: "When your brain feels like it's floating away from your body", feels: "Like watching yourself in a movie, but you're not really there" },
                      { word: "Self-Worth", meaning: "How much you believe you are a good person", feels: "Like knowing you are a superhero, even without a cape" },
                    ].map((item, idx) => (
                      <tr key={idx} className="border-b border-purple-100 hover:bg-purple-50">
                        <td className="py-4 font-semibold text-gray-800">{item.word}</td>
                        <td className="py-4 text-gray-700">{item.meaning}</td>
                        <td className="py-4 text-gray-600 italic">{item.feels}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Symptoms Section */}
        <section id="symptoms" className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <Smile className="w-8 h-8 text-orange-500" />
            <h3 className="text-3xl font-bold text-gray-800">The Stormy Feelings</h3>
          </div>
          <p className="text-lg text-gray-600 mb-8">When someone has CPTSD, they might have a lot of "stormy feelings" that are hard to manage. These are not their fault! It's their brain trying to keep them safe from the old hurts.</p>
          
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: "Feeling Scared and Alert",
                subtitle: "The Guard Dog",
                color: "bg-red-50 border-red-200",
                icon: "🐕",
                items: [
                  "Always Watching: They look for danger everywhere, even in safe places",
                  "Big Jumps: They jump or get scared easily by loud noises",
                  "Bad Dreams: They have nightmares about the scary things"
                ]
              },
              {
                title: "Feeling Bad About Themselves",
                subtitle: "The Broken Mirror",
                color: "bg-blue-50 border-blue-200",
                icon: "🪞",
                items: [
                  "Feeling Worthless: They feel like they are not good enough",
                  "Feeling Guilty: They think the bad things were their fault",
                  "Feeling Different: They feel like no one understands them"
                ]
              },
              {
                title: "Trouble with Feelings and Friends",
                subtitle: "The Bumpy Road",
                color: "bg-yellow-50 border-yellow-200",
                icon: "🛣️",
                items: [
                  "Big Feelings: They get very angry or very sad quickly",
                  "Pushing People Away: They find it hard to trust or be close",
                  "Zoning Out: They sometimes feel like they are not real"
                ]
              }
            ].map((symptom, idx) => (
              <Card key={idx} className={`border-2 ${symptom.color}`}>
                <CardHeader>
                  <div className="text-4xl mb-2">{symptom.icon}</div>
                  <CardTitle className="text-xl">{symptom.title}</CardTitle>
                  <CardDescription className="text-sm italic">{symptom.subtitle}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {symptom.items.map((item, itemIdx) => (
                      <li key={itemIdx} className="text-sm text-gray-700 leading-relaxed">
                        <strong>{item.split(":")[0]}:</strong> {item.split(":")[1]}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Healing Section */}
        <section id="healing" className="mb-16">
          <div className="flex items-center gap-3 mb-8">
            <Heart className="w-8 h-8 text-pink-500" />
            <h3 className="text-3xl font-bold text-gray-800">Finding the Sunshine (Healing)</h3>
          </div>
          <Card className="bg-white border-2 border-pink-200">
            <CardHeader>
              <CardTitle className="text-2xl">CPTSD Can Be Healed!</CardTitle>
              <CardDescription className="text-base">It takes time and help from kind people</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                {[
                  {
                    num: "1",
                    title: "Talk to a Helper (Therapy)",
                    desc: "A special kind of doctor or counselor (a therapist) can teach the brain how to feel safe again. They are like a guide who helps you walk out of the storm."
                  },
                  {
                    num: "2",
                    title: "Learn to Calm Down (Coping Skills)",
                    desc: "Things like deep breathing, drawing, playing, or talking about feelings can help turn the stormy feelings into sunshine."
                  },
                  {
                    num: "3",
                    title: "Be Kind to Yourself",
                    desc: "Remember that the hurt was not your fault. You are strong and brave for surviving it!"
                  }
                ].map((step, idx) => (
                  <div key={idx} className="flex gap-4 p-4 bg-pink-50 rounded-lg border border-pink-200">
                    <div className="flex-shrink-0 w-10 h-10 bg-pink-500 text-white rounded-full flex items-center justify-center font-bold text-lg">
                      {step.num}
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800 mb-2">{step.title}</h4>
                      <p className="text-gray-700 leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 px-4 mt-16">
        <div className="max-w-6xl mx-auto text-center">
          <p className="mb-4">© 2025 CPTSD Learning Center. Created to help everyone understand CPTSD.</p>
          <p className="text-gray-400 text-sm">This website is for educational purposes. If you or someone you know is struggling, please reach out to a mental health professional.</p>
        </div>
      </footer>
    </div>
  );
}

# CPTSD Learning Center - Project TODO

## Features to Implement

- [x] Home page with welcoming hero section
- [x] Navigation menu (What is CPTSD, Terminology, Symptoms, Healing)
- [x] What is CPTSD page with simple explanation
- [x] Terminology page with interactive glossary table
- [x] Symptoms page with visual breakdown of three main symptom categories
- [x] Healing & Help page with resources and coping strategies
- [x] Responsive design for mobile and desktop
- [x] Accessible color scheme and typography for easy reading
- [x] Footer with resources and references
- [ ] Create a checkpoint after completing the website
